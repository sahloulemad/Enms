// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: unused_import
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/cupertino.dart';
import 'main.dart';
import "package:flutter_localizations/flutter_localizations.dart";
import "package:cupertino_icons/cupertino_icons.dart";
import "package:google_fonts/google_fonts.dart";
import "package:shared_preferences/shared_preferences.dart";
import "package:fl_chart/fl_chart.dart";
import "package:intl/intl.dart";
import "package:provider/provider.dart";
